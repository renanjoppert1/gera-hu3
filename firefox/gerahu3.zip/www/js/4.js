(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[4],{

/***/ "26f3":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _node_modules_mini_css_extract_plugin_dist_loader_js_ref_6_oneOf_2_0_node_modules_css_loader_dist_cjs_js_ref_6_oneOf_2_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_6_oneOf_2_2_node_modules_quasar_app_lib_webpack_loader_auto_import_client_js_kebab_node_modules_vue_loader_lib_index_js_vue_loader_options_Popup_vue_vue_type_style_index_0_id_41bcc5fa_scoped_true_lang_css___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("7f31");
/* harmony import */ var _node_modules_mini_css_extract_plugin_dist_loader_js_ref_6_oneOf_2_0_node_modules_css_loader_dist_cjs_js_ref_6_oneOf_2_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_6_oneOf_2_2_node_modules_quasar_app_lib_webpack_loader_auto_import_client_js_kebab_node_modules_vue_loader_lib_index_js_vue_loader_options_Popup_vue_vue_type_style_index_0_id_41bcc5fa_scoped_true_lang_css___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_mini_css_extract_plugin_dist_loader_js_ref_6_oneOf_2_0_node_modules_css_loader_dist_cjs_js_ref_6_oneOf_2_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_6_oneOf_2_2_node_modules_quasar_app_lib_webpack_loader_auto_import_client_js_kebab_node_modules_vue_loader_lib_index_js_vue_loader_options_Popup_vue_vue_type_style_index_0_id_41bcc5fa_scoped_true_lang_css___WEBPACK_IMPORTED_MODULE_0__);
/* unused harmony reexport * */


/***/ }),

/***/ "7f31":
/***/ (function(module, exports, __webpack_require__) {

// extracted by mini-css-extract-plugin

/***/ }),

/***/ "b6eb":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// CONCATENATED MODULE: ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/@quasar/app/lib/webpack/loader.auto-import-client.js?kebab!./node_modules/vue-loader/lib??vue-loader-options!./src/pages/Popup.vue?vue&type=template&id=41bcc5fa&scoped=true&
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('q-page',{staticClass:"flex flex-center"},[_c('div',{staticClass:"row content"},[_c('div',{staticClass:"col-5 botoes"},[_c('q-btn',{attrs:{"color":"primary","label":"Gerar CPF"},on:{"click":_vm.gerarCPF}}),_c('q-btn',{attrs:{"color":"primary","label":"Gerar Placa"},on:{"click":_vm.gerarPlaca}})],1),_c('div',{staticClass:"col-7 field"},[_c('q-input',{directives:[{name:"maska",rawName:"v-maska",value:(_vm.mask(this.maskType)),expression:"mask(this.maskType)"}],attrs:{"label":"Valor"},scopedSlots:_vm._u([{key:"append",fn:function(){return [(_vm.text == '')?_c('q-icon',{attrs:{"name":"content_copy"}}):_c('q-btn',{attrs:{"flat":"","round":"","color":"primary","icon":"content_copy"},on:{"click":_vm.clipboard}})]},proxy:true}]),model:{value:(_vm.text),callback:function ($$v) {_vm.text=$$v},expression:"text"}})],1)])])}
var staticRenderFns = []


// CONCATENATED MODULE: ./src/pages/Popup.vue?vue&type=template&id=41bcc5fa&scoped=true&

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.reduce.js
var es_array_reduce = __webpack_require__("13d5");

// EXTERNAL MODULE: ./node_modules/quasar/src/utils/copy-to-clipboard.js
var copy_to_clipboard = __webpack_require__("cdde");

// EXTERNAL MODULE: ./node_modules/gerador-placa-veiculo/dist/index.js
var dist = __webpack_require__("3827");

// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.transform-quasar-imports.js!./node_modules/babel-loader/lib??ref--2-0!./node_modules/@quasar/app/lib/webpack/loader.auto-import-client.js?kebab!./node_modules/vue-loader/lib??vue-loader-options!./src/pages/Popup.vue?vue&type=script&lang=js&

//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
;

/* harmony default export */ var Popupvue_type_script_lang_js_ = ({
  name: "PagePopup",

  data() {
    return {
      text: "",
      maskType: ""
    };
  },

  methods: {
    clipboard() {
      Object(copy_to_clipboard["a" /* default */])(this.text).then(() => {
        this.$q.notify({
          progress: true,
          timeout: 1000,
          message: "Copiado!",
          color: "primary"
        });
      }).catch(err => {
        console.log(err); // fail
      });
    },

    mask(maskType) {
      switch (maskType) {
        case "cpf":
          return "###.###.###-##";
          break;

        default:
          return "";
          break;
      }
    },

    gerarPlaca() {
      this.text = Object(dist["geradorPlacaVeiculo"])();
    },

    gerarCPF() {
      const rnd = n => Math.round(Math.random() * n);

      const mod = (base, div) => Math.round(base - Math.floor(base / div) * div);

      const n = Array(9).fill("").map(() => rnd(9));
      let d1 = n.reduce((total, number, index) => total + number * (10 - index), 0);
      d1 = 11 - mod(d1, 11);
      if (d1 >= 10) d1 = 0;
      let d2 = d1 * 2 + n.reduce((total, number, index) => total + number * (11 - index), 0);
      d2 = 11 - mod(d2, 11);
      if (d2 >= 10) d2 = 0;
      this.maskType = "cpf";
      this.text = `${n.join("")}${d1}${d2}`;
    }

  }
});
// CONCATENATED MODULE: ./src/pages/Popup.vue?vue&type=script&lang=js&
 /* harmony default export */ var pages_Popupvue_type_script_lang_js_ = (Popupvue_type_script_lang_js_); 
// EXTERNAL MODULE: ./src/pages/Popup.vue?vue&type=style&index=0&id=41bcc5fa&scoped=true&lang=css&
var Popupvue_type_style_index_0_id_41bcc5fa_scoped_true_lang_css_ = __webpack_require__("26f3");

// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__("2877");

// EXTERNAL MODULE: ./node_modules/quasar/src/components/page/QPage.js
var QPage = __webpack_require__("9989");

// EXTERNAL MODULE: ./node_modules/quasar/src/components/btn/QBtn.js + 6 modules
var QBtn = __webpack_require__("9c40");

// EXTERNAL MODULE: ./node_modules/quasar/src/components/input/QInput.js + 9 modules
var QInput = __webpack_require__("27f9");

// EXTERNAL MODULE: ./node_modules/quasar/src/components/icon/QIcon.js + 1 modules
var QIcon = __webpack_require__("0016");

// EXTERNAL MODULE: ./node_modules/@quasar/app/lib/webpack/runtime.auto-import.js
var runtime_auto_import = __webpack_require__("eebe");
var runtime_auto_import_default = /*#__PURE__*/__webpack_require__.n(runtime_auto_import);

// CONCATENATED MODULE: ./src/pages/Popup.vue






/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  pages_Popupvue_type_script_lang_js_,
  render,
  staticRenderFns,
  false,
  null,
  "41bcc5fa",
  null
  
)

/* harmony default export */ var Popup = __webpack_exports__["default"] = (component.exports);





runtime_auto_import_default()(component, 'components', {QPage: QPage["a" /* default */],QBtn: QBtn["a" /* default */],QInput: QInput["a" /* default */],QIcon: QIcon["a" /* default */]});


/***/ })

}]);